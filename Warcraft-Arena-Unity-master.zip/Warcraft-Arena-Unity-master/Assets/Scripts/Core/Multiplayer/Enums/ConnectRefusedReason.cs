﻿namespace Core
{
    public enum ConnectRefusedReason
    {
        None,
        InvalidToken,
        InvalidVersion,
        UnsupportedDevice,
    }
}
