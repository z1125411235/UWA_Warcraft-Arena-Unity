﻿namespace Core
{
    public enum DisconnectReason
    {
        Unknown,
        Timeout,
        Error,
        Disconnected,
        DisconnectedFromMaster
    }
}
