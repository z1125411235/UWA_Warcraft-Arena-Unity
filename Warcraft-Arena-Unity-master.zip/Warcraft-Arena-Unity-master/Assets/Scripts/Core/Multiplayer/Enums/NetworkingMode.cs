﻿namespace Core
{
    public enum NetworkingMode
    {
        None,
        Both,
        Server,
        Client,
    }
}
