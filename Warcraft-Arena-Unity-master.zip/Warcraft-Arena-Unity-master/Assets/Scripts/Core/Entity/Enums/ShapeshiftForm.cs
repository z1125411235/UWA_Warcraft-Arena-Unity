﻿namespace Core
{
    public enum ShapeShiftForm
    {
        None = 0,
        CatForm = 1,
    }
}