﻿namespace Core
{
    public enum StatModifierType
    {
        BaseValue = 0,
        BasePercent = 1,
        TotalValue = 2,
        TotalPercent = 3
    }
}
