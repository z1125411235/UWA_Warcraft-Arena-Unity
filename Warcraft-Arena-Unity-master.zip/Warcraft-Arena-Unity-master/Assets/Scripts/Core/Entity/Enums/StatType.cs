﻿namespace Core
{
    public enum StatType
    {
        Strength,
        Agility,
        Stamina,
        Intellect,
    }
}
