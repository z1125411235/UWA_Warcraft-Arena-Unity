﻿namespace Core
{
    public enum MovementSlot
    {
        Idle,
        Active,
        Controlled,
        Physics
    }
}
