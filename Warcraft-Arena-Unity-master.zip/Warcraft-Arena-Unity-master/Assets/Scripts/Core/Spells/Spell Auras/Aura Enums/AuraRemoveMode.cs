﻿namespace Core
{
    public enum AuraRemoveMode
    {
        None = 0,
        Default,
        Cancel,
        Dispel,
        Expired,
        Death,
        Detach,
        Spell,
        Interrupt,
        Immunity
    }
}
