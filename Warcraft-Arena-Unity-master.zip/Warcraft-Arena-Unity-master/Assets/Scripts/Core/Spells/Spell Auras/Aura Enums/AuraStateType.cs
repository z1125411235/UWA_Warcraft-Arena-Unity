﻿namespace Core
{
    public enum AuraStateType
    {
        None,
        Frozen,
        Defense,
        Berserking,
        Judgement,
        Conflagrate,
        Swiftmend,
        DeadlyPoison,
        Enrage,
        Bleeding
    }
}
