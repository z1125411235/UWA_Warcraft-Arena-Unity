﻿namespace Core
{
    public enum AuraInterruptValueCalculationType
    {
        Direct = 0,
        MaxHealthCasterPercent = 1,
        MaxHealthTargetPercent = 2,
    }
}
