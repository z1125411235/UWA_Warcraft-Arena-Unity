﻿namespace Core
{
    public enum AuraEffectHandleGroup
    {
        Unique = 0,
        SpeedChange = 1,
        RootStateChange = 2,
        BasicModifier = 3,
        PeriodicDamage = 4,
        Confuse = 5,
        Stun = 6,
    }
}
