﻿namespace Core
{
    public interface IAuraScriptSpellDamageHandler
    {
        void OnSpellDamageDone(SpellDamageInfo damageInfo);
    }
}
