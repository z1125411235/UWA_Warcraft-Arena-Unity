﻿namespace Core
{
    public enum SpellDamageCalculationType
    {
        Direct = 0,
        SpellPowerPercent = 1,
    }
}
