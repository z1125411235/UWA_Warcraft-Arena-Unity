﻿namespace Core
{
    public enum SpellDamageType
    {
        Direct = 1,
        Dot = 2,
        Heal = 3,
        Pure = 4,
        Self = 5,
        Processed = 6
    }
}
