﻿namespace Core
{
    public enum SpellDispelType
    {
        None,
        Magic,
        Curse,
        Disease,
        Poison,
        Stealth,
        Invisibility,
        Enrage,
    }
}
