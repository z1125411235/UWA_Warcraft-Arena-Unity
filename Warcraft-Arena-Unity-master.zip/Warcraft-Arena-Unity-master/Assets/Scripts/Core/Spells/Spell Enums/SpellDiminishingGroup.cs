﻿namespace Core
{
    public enum SpellDiminishingGroup
    {
        None,
        Root,
        Stun,
        Incapacitate,
        Disorient,
        Silence,
        AoeKnockback,
    }
}
