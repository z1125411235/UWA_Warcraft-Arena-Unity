﻿namespace Core
{
    public enum SpellCustomErrors
    {
        None = 0
    }
}
