﻿namespace Core
{
    public enum SpellAbsorbCalculationType
    {
        Direct = 0,
        MaxHealthPercent = 1,
        SpellPowerPercent = 2,
    }
}
