﻿namespace Core
{
    public enum SpellDamageClass
    {
        None,
        Magic,
        Melee,
        Ranged,
    }
}
