﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Arena.Server")]
[assembly: InternalsVisibleTo("Arena.Editor")]