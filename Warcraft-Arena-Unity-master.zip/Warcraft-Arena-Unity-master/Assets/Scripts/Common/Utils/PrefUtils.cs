﻿namespace Common
{
    public static class PrefUtils
    {
        public const string PlayerNamePref = nameof(PlayerNamePref);
        public const string PlayerServerNamePref = nameof(PlayerServerNamePref);
    }
}
