﻿using UnityEngine;

namespace Common
{
    public class EnumFlagAttribute : PropertyAttribute { }
}
