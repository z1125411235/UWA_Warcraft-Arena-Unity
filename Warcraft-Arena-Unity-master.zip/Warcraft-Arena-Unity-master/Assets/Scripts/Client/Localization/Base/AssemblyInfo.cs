﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Arena.Editor")]