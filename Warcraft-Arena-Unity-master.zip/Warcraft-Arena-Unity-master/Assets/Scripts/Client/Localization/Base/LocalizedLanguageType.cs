﻿namespace Client.Localization
{
    public enum LocalizedLanguageType
    {
        English,
        Spanish,
        German,
        Italian
    }
}
