﻿namespace Client.UI
{
    // ReSharper disable once UnusedTypeParameter
    public interface IPanel<TScreen> where TScreen : UIPanelController
    {
    }
}
