﻿namespace Client
{
    public enum TooltipSize
    {
        Small,
        Normal
    }
}
