﻿namespace Client
{
    public enum InterfaceCanvasType
    {
        Nameplate
    }
}
