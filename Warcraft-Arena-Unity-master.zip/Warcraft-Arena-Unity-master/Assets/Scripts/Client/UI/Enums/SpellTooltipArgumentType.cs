﻿namespace Client
{
    public enum SpellTooltipArgumentType
    {
        Duration,
        Value,
        Radius,
        Period
    }
}
