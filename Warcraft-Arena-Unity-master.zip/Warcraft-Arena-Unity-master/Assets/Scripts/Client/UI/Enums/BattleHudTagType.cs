﻿namespace Client
{
    public enum BattleHudTagType
    {
        SpellOverlay
    }
}
