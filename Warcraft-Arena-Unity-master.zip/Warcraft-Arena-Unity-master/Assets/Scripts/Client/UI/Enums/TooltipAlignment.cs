﻿namespace Client
{
    public enum TooltipAlignment
    {
        FromBottom,
        FromRight,
        FromTop,
        FromLeft,
        FromTopLeft
    }
}