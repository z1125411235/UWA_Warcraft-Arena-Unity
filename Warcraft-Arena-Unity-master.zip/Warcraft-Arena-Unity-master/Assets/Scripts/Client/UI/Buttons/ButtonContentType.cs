﻿namespace Client
{
    public enum ButtonContentType
    {
        Spell,
        Empty
    }
}
