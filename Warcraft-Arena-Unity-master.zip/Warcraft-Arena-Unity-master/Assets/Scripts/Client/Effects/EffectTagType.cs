﻿namespace Client
{
    public enum EffectTagType
    {
        Bottom,
        Foot,
        Impact,
        ImpactStatic,
        RightHand,
        LeftHand
    }
}
