﻿namespace Client
{
    public enum TargetingDistance
    {
        Any,
        Near,
        Far
    }
}
