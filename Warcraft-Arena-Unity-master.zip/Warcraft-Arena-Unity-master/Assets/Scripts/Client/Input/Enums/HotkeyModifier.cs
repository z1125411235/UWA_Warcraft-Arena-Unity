﻿namespace Client
{
    public enum HotkeyModifier
    {
        None,
        LeftControl,
        LeftAlt,
        LeftShift
    }
}
