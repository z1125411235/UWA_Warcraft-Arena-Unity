﻿namespace Client
{
    public enum TargetingMode
    {
        Normal,
        Self,
        Clear
    }
}
