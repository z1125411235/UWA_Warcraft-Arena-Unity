﻿namespace Client
{
    public enum HotkeyState
    {
        Pressed,
        Released,
    }
}
