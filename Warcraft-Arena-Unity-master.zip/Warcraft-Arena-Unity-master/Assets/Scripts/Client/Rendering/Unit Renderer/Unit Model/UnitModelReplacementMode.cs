﻿namespace Client
{
    public enum UnitModelReplacementMode
    {
        ScopeIn,
        ScopeOut,
        Complete,
        Transformation
    }
}
