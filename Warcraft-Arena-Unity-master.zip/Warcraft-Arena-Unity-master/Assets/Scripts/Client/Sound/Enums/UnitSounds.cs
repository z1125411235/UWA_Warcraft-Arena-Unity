﻿namespace Client
{
    public enum UnitSounds
    {
        Death = 1,
        Hello = 2,
        Laugh = 3,
        Train = 4,
        Chicken = 5,
        No = 6,
        Yes = 7,
        Kiss = 8,
        Cry = 9,
        Roar = 10
    }
}
