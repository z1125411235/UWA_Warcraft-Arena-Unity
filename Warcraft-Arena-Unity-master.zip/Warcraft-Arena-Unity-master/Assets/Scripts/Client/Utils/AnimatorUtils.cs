﻿namespace Client
{
    public static class AnimatorUtils
    {
        public const string ResurrectingAnimationParam = "Resurrecting";
        public const string DyingAnimationParam = "Dying";
    }
}
